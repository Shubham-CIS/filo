function Header() {


    return (
      <>
        This is Header Page
      </>
    );
  }
  
  export default Header;